function showAutoComplete(id, obj) {
  $(id).autocomplete(obj);
}